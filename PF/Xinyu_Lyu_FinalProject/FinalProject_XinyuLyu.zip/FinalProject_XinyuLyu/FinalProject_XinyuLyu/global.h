#pragma once
class global//It is a design pattern called: Singleton. It can be a substitute for a global variable, ensuring a class has only one object instance, and provide an access method. 
{
public:
	static double Cash_Balance;
};
