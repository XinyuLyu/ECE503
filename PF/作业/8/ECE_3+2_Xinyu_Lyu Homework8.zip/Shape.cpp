#include<iostream>
using namespace std;
#include"Shape.h"

Shape::Shape()
{
} 
double Shape::getVolume() const
{
	return 0.0;
}  

